export { default } from './Star'
