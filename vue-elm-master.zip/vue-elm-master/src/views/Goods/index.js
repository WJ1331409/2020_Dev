export { default } from './Goods'
