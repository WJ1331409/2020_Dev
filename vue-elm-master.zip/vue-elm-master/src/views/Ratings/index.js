export { default } from './Ratings'
