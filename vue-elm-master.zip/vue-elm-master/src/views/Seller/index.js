export { default } from './Seller'
